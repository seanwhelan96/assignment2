const  users = [
    {
        'username': 'user1',
        'password': 'test1',
    },
    {
        'username': 'user2',
        'password': 'test2',
    },
    {
        'username': 'user3',
        'password': 'test3',
    },
];
export default users;